<!DOCTYPE html>
<html>

<head> <title> Home Page </title>

</head>
<style>
        .a{
            text-align: center;
            border: 3px solid red; 
            font-family:"times new roman",serif;
            background-color:lightsalmon;
        }
        .container{  
text-align: center;  

width: 300px;  
height: 200px;  
padding-top: 30px; 


} 
.b{
    height:40px;
    width:120px;
}
.c{
    font-color: black;
}

    
#btn{  
font-size: 25px;  
}
        </style>

▾ <body>
    <marquee>
      <P>  PAY THE BILL BEFORE DUE-DATE TO AVOID PENALTY.NOT PAYING DUE-AMOUNT INCREASES PENALTY</P> </marquee>
<div class="Loginbox">
     <br><br>

    <h1 class="a">Guidelines</h1>
    <div class="c">
    <form action="front.php" method="post" style="text-align:center;">
      <p>

      Please observe the following guidelines for speedy settlement of your grievances:<br>

For online lodging of complaints and status update through website www.indiapost.gov.in<br>
 (Go to home page and click on Customer Complaints​ link, select option Register Your Complaint for lodging com​​plaint and select <br>
 option Track your Complaint for knowing the position of the case.)

Register your complaint in the Post Office where transaction has taken place and get acknowledgement.<br>

Approach next higher authority of the Department if the complaint is not settled in a reasonable time.<br>

The standards for resolving complaints are announced through the Citizen Charter of Department of Posts available in <br>
link About Us on Home page of this website.<br>

Complaint on Postal Services addressed to Postal Directorate, New Delhi, may only be addressed to concerned officer and sent on given email, telephone or fax number
</p><br>
<input type='submit' value='HOME' id="submit"/>


</form>



<form action='front.php' method="POST" style="text-align:center;">

       </form>


</form>
</div>
</body>
</html>
